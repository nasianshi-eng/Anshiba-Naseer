from fastapi.testclient import TestClient

from backend.main import app
from backend.routes import generate_document
from backend.schemas import DocumentRequest

client = TestClient(app)

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["name"] == "LegalEase"

def test_health():
    assert client.get("/health").json() == {"status": "ok"}

def test_generate_validation():
    response = client.post("/generate", json={
        "document_type": "",
        "parties": "A",
        "terms": "B",
        "effective_date": "2026-09-23",
    })
    assert response.status_code == 422

def test_generate_mock(monkeypatch):
    class FakeGenerator:
        def __init__(self):
            pass
        def generate_document(self, *args):
            return "TEST LEGAL DOCUMENT"

    monkeypatch.setattr(
        "backend.routes.GeminiDocumentGenerator",
        FakeGenerator
    )

    response = client.post("/generate", json={
        "document_type": "NDA",
        "parties": "Alice, Bob",
        "terms": "Confidentiality",
        "effective_date": "2026-09-23",
    })
    assert response.status_code == 200
    assert response.json()["document"] == "TEST LEGAL DOCUMENT"
