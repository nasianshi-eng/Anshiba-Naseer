from io import BytesIO
from pathlib import Path

from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
)
from reportlab.lib import colors

from backend.document_generators.common import sanitize_text, split_sections, terms_list

LOGO_PATH = Path(__file__).resolve().parents[2] / "assets" / "logo.png"

def format_pdf(text: str, doc_type: str, terms: str = "") -> bytes:
    output = BytesIO()
    doc = SimpleDocTemplate(
        output,
        pagesize=LETTER,
        rightMargin=0.7 * inch,
        leftMargin=0.7 * inch,
        topMargin=0.75 * inch,
        bottomMargin=0.7 * inch,
        title=sanitize_text(doc_type),
        author="LegalEase",
    )

    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "LegalTitle", parent=styles["Title"], fontName="Helvetica-Bold",
        fontSize=16, leading=20, alignment=TA_CENTER, spaceAfter=12
    )
    heading = ParagraphStyle(
        "LegalHeading", parent=styles["Heading2"], fontName="Helvetica-Bold",
        fontSize=11.5, leading=15, spaceBefore=8, spaceAfter=5
    )
    body = ParagraphStyle(
        "LegalBody", parent=styles["BodyText"], fontName="Helvetica",
        fontSize=10.5, leading=15, spaceAfter=7
    )
    story = []

    if LOGO_PATH.exists():
        img = Image(str(LOGO_PATH), width=0.9 * inch, height=0.9 * inch)
        img.hAlign = "CENTER"
        story.append(img)
    story.append(Paragraph(sanitize_text(doc_type).upper(), title))

    for h, b in split_sections(text):
        if h != "Document":
            story.append(Paragraph(sanitize_text(h), heading))
        for para in b.split("\n"):
            if para.strip():
                story.append(Paragraph(sanitize_text(para.strip()), body))

    supplied_terms = terms_list(terms)
    if supplied_terms:
        story.append(Paragraph("User-Provided Terms", heading))
        data = [["No.", "Term"]] + [[str(i), sanitize_text(t)] for i, t in enumerate(supplied_terms, 1)]
        table = Table(data, colWidths=[0.5 * inch, 5.8 * inch], repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8EEF7")),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("FONTSIZE", (0, 0), (-1, -1), 9.5),
            ("LEADING", (0, 0), (-1, -1), 12),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(table)

    def footer(canvas, doc_obj):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.drawCentredString(
            LETTER[0] / 2, 0.35 * inch,
            f"LegalEase - AI-generated draft | Page {doc_obj.page}"
        )
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()
