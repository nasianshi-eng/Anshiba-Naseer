from io import BytesIO
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Inches, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from backend.document_generators.common import sanitize_text, split_sections, terms_list

LOGO_PATH = Path(__file__).resolve().parents[2] / "assets" / "logo.png"

def _set_cell_shading(cell, fill="E8EEF7"):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)

def format_docx(text: str, doc_type: str, terms: str = "") -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)

    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(11)

    if LOGO_PATH.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(LOGO_PATH), width=Inches(1.25))

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(sanitize_text(doc_type).upper())
    run.bold = True
    run.font.name = "Times New Roman"
    run.font.size = Pt(16)

    for heading, body in split_sections(text):
        if heading == "Document" and body.strip() == sanitize_text(text):
            for para in body.split("\n"):
                if para.strip():
                    doc.add_paragraph(para.strip())
            continue

        h = doc.add_paragraph()
        r = h.add_run(heading)
        r.bold = True
        r.font.name = "Times New Roman"
        r.font.size = Pt(12)

        for para in body.split("\n"):
            if para.strip():
                p = doc.add_paragraph(para.strip())
                p.paragraph_format.space_after = Pt(6)

    supplied_terms = terms_list(terms)
    if supplied_terms:
        doc.add_paragraph().add_run("User-Provided Terms").bold = True
        table = doc.add_table(rows=1, cols=2)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        hdr[0].text = "No."
        hdr[1].text = "Term"
        for c in hdr:
            _set_cell_shading(c)
            c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for i, term in enumerate(supplied_terms, 1):
            cells = table.add_row().cells
            cells[0].text = str(i)
            cells[1].text = term

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("LegalEase - AI-generated draft | Review with qualified legal counsel before use.").italic = True

    output = BytesIO()
    doc.save(output)
    return output.getvalue()
