# LegalEase — AI-Powered Legal Document Generator

LegalEase is a FastAPI + Streamlit application based on the supplied project documentation. It accepts a document type, parties, terms, and effective date, uses Gemini to draft a structured document, provides an editable preview, and exports the edited document as TXT, DOCX, or PDF.

> **Legal notice:** AI-generated text is a drafting aid, not legal advice. Users should have important documents reviewed by a qualified lawyer in the relevant jurisdiction.

## Architecture

- **Frontend:** Streamlit (`frontend/app.py`)
- **Backend:** FastAPI (`backend/main.py`, `backend/routes.py`)
- **AI:** Google Gemini through the current `google-genai` SDK (`backend/ai_core/gemini_generator.py`)
- **Export:** python-docx for DOCX, ReportLab for PDF, native UTF-8 TXT
- **Configuration:** `.env`
- **Tests:** pytest

The original documentation specifies Gemini 1.5 Pro and `google-generativeai`. Those are legacy choices now. This implementation uses the current Google GenAI Python SDK and a configurable current model; the default is `gemini-3.8-flash`. See the official Google Gemini docs for current model availability.

## Project tree

```text
LegalEase/
├── backend/
│   ├── __init__.py
│   ├── main.py
│   ├── routes.py
│   ├── config.py
│   ├── schemas.py
│   ├── ai_core/
│   │   ├── __init__.py
│   │   └── gemini_generator.py
│   └── document_generators/
│       ├── __init__.py
│       ├── common.py
│       ├── docx_generator.py
│       └── pdf_generator.py
├── frontend/
│   ├── __init__.py
│   └── app.py
├── assets/
│   └── logo.png
├── tests/
│   ├── test_api.py
│   └── test_generators.py
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── Procfile
├── requirements.txt
└── README.md
```

## 1. VS Code setup

Install Python 3.10+.

Open the `LegalEase` folder in VS Code and create a terminal.

### Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

Open `.env` and set:

```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash
BACKEND_URL=http://127.0.0.1:8000
```

Get a Gemini API key from Google AI Studio. Do not commit the `.env` file.

## 2. Run the backend

From the project root:

```bash
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Open:

- API root: http://127.0.0.1:8000/
- Health: http://127.0.0.1:8000/health
- Swagger UI: http://127.0.0.1:8000/docs

## 3. Run the frontend

Open a second VS Code terminal, activate the same environment, then:

```bash
streamlit run frontend/app.py
```

Open the URL Streamlit prints, normally:

```text
http://localhost:8501
```

## 4. Test without an API key

The unit/API tests do not call Gemini. They validate schemas, export generation, and a mocked `/generate` request.

```bash
pytest -q
```

For a real end-to-end test, put a valid `GEMINI_API_KEY` in `.env`, start the backend and frontend, then generate a sample NDA.

## 5. API example

POST `/generate`:

```json
{
  "document_type": "Non-Disclosure Agreement",
  "parties": "Jane Doe (Disclosing Party), TechNova Inc. (Receiving Party)",
  "terms": "Confidential information must be protected; No disclosure to third parties; Agreement may be terminated with 15 days notice",
  "effective_date": "2026-09-23"
}
```

Response:

```json
{
  "document": "...generated legal document..."
}
```

## 6. Export behavior

- TXT: UTF-8 plain text.
- DOCX: title, headings, body paragraphs, terms table, footer.
- PDF: branded title, headings, body, terms table, page footer.
- Logo: `assets/logo.png` is embedded when available.

## 7. Environment variables

| Variable | Required | Default |
|---|---|---|
| `GEMINI_API_KEY` | Yes for AI generation | — |
| `GEMINI_MODEL` | No | `gemini-3.8-flash` |
| `BACKEND_URL` | No | `http://127.0.0.1:8000` |
| `CORS_ORIGINS` | No | `http://localhost:8501,http://127.0.0.1:8501` |
| `MAX_INPUT_CHARS` | No | `12000` |

## 8. Docker

Create `.env` first, then:

```bash
docker compose up --build
```

Backend: http://localhost:8000  
Frontend: http://localhost:8501

## Troubleshooting

### `GEMINI_API_KEY is not configured`
Create `.env` from `.env.example` and add a valid key.

### Gemini model not available
Set `GEMINI_MODEL` to a model available to your API project. The model is deliberately configurable.

### Frontend cannot connect
Make sure FastAPI is running on port 8000 and `BACKEND_URL` points to it.

### PDF has no custom font
The exporter uses ReportLab's built-in fonts by default so a fresh installation works without extra font files.

### PowerShell blocks activation
Run PowerShell as your user and, if appropriate for your machine:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

