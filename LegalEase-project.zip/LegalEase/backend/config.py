import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
    backend_url: str = os.getenv("BACKEND_URL", "http://127.0.0.1:8000")
    cors_origins: tuple[str, ...] = tuple(
        item.strip() for item in os.getenv(
            "CORS_ORIGINS",
            "http://localhost:8501,http://127.0.0.1:8501"
        ).split(",") if item.strip()
    )
    max_input_chars: int = int(os.getenv("MAX_INPUT_CHARS", "12000"))

settings = Settings()
