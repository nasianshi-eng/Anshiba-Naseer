import re
from html import escape

def sanitize_text(text: str) -> str:
    if not text:
        return ""
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\u00a0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return re.sub(r"[ \t]+\n", "\n", text).strip()

def split_sections(text: str) -> list[tuple[str, str]]:
    lines = [line.strip() for line in sanitize_text(text).splitlines()]
    sections: list[tuple[str, str]] = []
    current_heading = "Document"
    body: list[str] = []

    heading_re = re.compile(
        r"^(?:\d+(?:\.\d+)*[\.)]?\s+)?"
        r"(PARTIES|RECITALS|DEFINITIONS|TERMS|TERM|PAYMENT|"
        r"CONFIDENTIALITY|TERMINATION|GOVERNING LAW|SIGNATURES|"
        r"USER-PROVIDED TERMS|AGREEMENT|RESPONSIBILITIES|"
        r"OBLIGATIONS|SERVICES|INTELLECTUAL PROPERTY|"
        r"DISPUTE|NOTICES|GENERAL PROVISIONS)\b.*$",
        re.I,
    )

    for line in lines:
        if not line:
            if body:
                sections.append((current_heading, "\n".join(body)))
                body = []
            continue
        if heading_re.match(line) and len(line) <= 100:
            if body:
                sections.append((current_heading, "\n".join(body)))
                body = []
            current_heading = line
        else:
            body.append(line)

    if body:
        sections.append((current_heading, "\n".join(body)))
    return sections or [("Document", sanitize_text(text))]

def terms_list(terms: str) -> list[str]:
    return [item.strip() for item in terms.split(";") if item.strip()]

def html_preview(text: str) -> str:
    safe = escape(sanitize_text(text))
    safe = safe.replace("\n\n", "</p><p>").replace("\n", "<br>")
    return f'<div class="legal-card"><p>{safe}</p></div>'
