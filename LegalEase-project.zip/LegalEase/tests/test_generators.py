from backend.document_generators.common import sanitize_text, terms_list
from backend.document_generators.docx_generator import format_docx
from backend.document_generators.pdf_generator import format_pdf

def test_sanitize_text():
    assert sanitize_text("Hello\u2014world\u00a0!") == "Hello-world !"

def test_terms_list():
    assert terms_list("One; Two; ; Three") == ["One", "Two", "Three"]

def test_docx_export():
    data = format_docx(
        "PARTIES\n\nAlice and Bob\n\nCONFIDENTIALITY\n\nKeep information private.",
        "NDA",
        "Keep information private;No disclosure",
    )
    assert data.startswith(b"PK")
    assert len(data) > 1000

def test_pdf_export():
    data = format_pdf(
        "PARTIES\n\nAlice and Bob\n\nCONFIDENTIALITY\n\nKeep information private.",
        "NDA",
        "Keep information private;No disclosure",
    )
    assert data.startswith(b"%PDF")
    assert len(data) > 1000
