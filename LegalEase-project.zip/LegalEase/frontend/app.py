import html
import os
from datetime import date

import requests
import streamlit as st
from dotenv import load_dotenv

from backend.document_generators.docx_generator import format_docx
from backend.document_generators.pdf_generator import format_pdf

load_dotenv()

BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="wide",
)

st.markdown("""
<style>
.main-title { text-align:center; font-size:2.2rem; font-weight:800; margin-bottom:0.2rem; }
.subtitle { text-align:center; color:#718096; margin-bottom:1.5rem; }
.legal-card {
    background:#111827; color:#f9fafb; padding:1.25rem; border-radius:14px;
    max-height:560px; overflow-y:auto; line-height:1.7; border:1px solid #374151;
}
.small-note { color:#6b7280; font-size:0.85rem; }
</style>
""", unsafe_allow_html=True)

logo_path = os.path.join(os.path.dirname(__file__), "..", "assets", "logo.png")
if os.path.exists(logo_path):
    c1, c2, c3 = st.columns([1, 2, 1])
    with c2:
        st.image(logo_path, width=110)

st.markdown('<div class="main-title">LegalEase</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="subtitle">AI-powered legal document drafting, editing and export</div>',
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("Document details")
    document_type = st.text_input(
        "Document type",
        placeholder="e.g. Non-Disclosure Agreement",
    )
    parties = st.text_area(
        "Parties involved",
        placeholder="Jane Doe (Disclosing Party), TechNova Inc. (Receiving Party)",
        height=100,
    )
    terms = st.text_area(
        "Terms & conditions",
        placeholder="Use semicolons between terms: Confidentiality must be maintained; No disclosure to third parties",
        height=150,
    )
    effective_date = st.date_input("Effective date", value=date.today())
    generate = st.button("Generate Document", type="primary", use_container_width=True)

st.caption(
    "Drafting aid only. Review important legal documents with qualified legal counsel "
    "before signing or relying on them."
)

if generate:
    if not all([document_type.strip(), parties.strip(), terms.strip()]):
        st.error("Please complete document type, parties, and terms.")
    else:
        payload = {
            "document_type": document_type.strip(),
            "parties": parties.strip(),
            "terms": terms.strip(),
            "effective_date": effective_date.isoformat(),
        }
        with st.spinner("Generating your document..."):
            try:
                response = requests.post(
                    f"{BACKEND_URL}/generate",
                    json=payload,
                    timeout=180,
                )
                response.raise_for_status()
                st.session_state["document"] = response.json()["document"]
                st.session_state["doc_type"] = document_type.strip()
                st.session_state["terms"] = terms.strip()
            except requests.RequestException as exc:
                detail = ""
                if getattr(exc, "response", None) is not None:
                    try:
                        detail = exc.response.json().get("detail", "")
                    except Exception:
                        pass
                st.error(f"Backend request failed. {detail or exc}")

if "document" in st.session_state:
    document = st.session_state["document"]

    st.subheader("Generated document")

    with st.expander("Preview", expanded=True):
        safe = html.escape(document).replace("\n\n", "</p><p>").replace("\n", "<br>")
        st.markdown(f'<div class="legal-card"><p>{safe}</p></div>', unsafe_allow_html=True)

    st.subheader("Edit document")
    edited = st.text_area(
        "Modify the generated text before export.",
        value=document,
        height=520,
        label_visibility="collapsed",
    )
    st.session_state["document"] = edited

    txt_bytes = edited.encode("utf-8")
    docx_bytes = format_docx(
        edited,
        st.session_state.get("doc_type", document_type or "Legal Document"),
        st.session_state.get("terms", terms),
    )
    pdf_bytes = format_pdf(
        edited,
        st.session_state.get("doc_type", document_type or "Legal Document"),
        st.session_state.get("terms", terms),
    )

    c1, c2, c3 = st.columns(3)
    with c1:
        st.download_button(
            "Download TXT",
            data=txt_bytes,
            file_name="legalease_document.txt",
            mime="text/plain",
            use_container_width=True,
        )
    with c2:
        st.download_button(
            "Download DOCX",
            data=docx_bytes,
            file_name="legalease_document.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            use_container_width=True,
        )
    with c3:
        st.download_button(
            "Download PDF",
            data=pdf_bytes,
            file_name="legalease_document.pdf",
            mime="application/pdf",
            use_container_width=True,
        )
