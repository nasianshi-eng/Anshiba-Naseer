from fastapi import APIRouter, HTTPException

from backend.config import settings
from backend.schemas import DocumentRequest, DocumentResponse
from backend.ai_core.gemini_generator import (
    GeminiConfigurationError,
    GeminiDocumentGenerator,
    GeminiGenerationError,
)

router = APIRouter()

@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest) -> DocumentResponse:
    combined_length = sum(
        len(v) for v in (
            request.document_type,
            request.parties,
            request.terms,
            request.effective_date,
        )
    )
    if combined_length > settings.max_input_chars:
        raise HTTPException(
            status_code=413,
            detail=f"Input is too large. Maximum combined input is {settings.max_input_chars} characters.",
        )

    try:
        generator = GeminiDocumentGenerator()
        document = generator.generate_document(
            request.document_type,
            request.parties,
            request.terms,
            request.effective_date,
        )
        return DocumentResponse(document=document)
    except GeminiConfigurationError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    except GeminiGenerationError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
