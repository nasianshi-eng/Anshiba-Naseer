# Implementation notes

## Source-document alignment

The supplied project document describes:
- Streamlit frontend
- FastAPI backend
- Gemini AI integration
- `/generate` POST endpoint
- Inputs: document type, parties, terms, effective date
- editable preview
- TXT/DOCX/PDF downloads
- logo and footer formatting
- local deployment/testing

This implementation covers those requirements.

## Deliberate modernization

The source documentation names Gemini 1.5 Pro and the `google-generativeai` package. Current Google documentation recommends the `google-genai` SDK and lists current Gemini model IDs. Therefore `GEMINI_MODEL` is configurable and defaults to a current stable Gemini model. The application does not hard-code a legacy model.

## Security basics included

- API key is read from environment variables.
- `.env` is ignored by Git.
- Input length is capped.
- CORS is restricted to configured frontend origins.
- AI output is treated as untrusted text and escaped for HTML preview.
- No generated document is persisted server-side.
