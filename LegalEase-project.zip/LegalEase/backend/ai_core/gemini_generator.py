from backend.config import settings

class GeminiConfigurationError(RuntimeError):
    pass

class GeminiGenerationError(RuntimeError):
    pass

class GeminiDocumentGenerator:
    """Generate structured legal-document drafts using Google's current GenAI SDK."""

    def __init__(self, api_key: str | None = None, model: str | None = None):
        key = api_key or settings.gemini_api_key
        if not key:
            raise GeminiConfigurationError(
                "GEMINI_API_KEY is not configured. Add it to your .env file."
            )
        self.model = model or settings.gemini_model
        try:
            from google import genai
        except ImportError as exc:
            raise GeminiConfigurationError(
                "The google-genai package is not installed. Run: pip install -r requirements.txt"
            ) from exc
        self.client = genai.Client(api_key=key)

    @staticmethod
    def _prompt(document_type: str, parties: str, terms: str, effective_date: str) -> str:
        return f"""
You are a careful legal-document drafting assistant.

Create a professional, editable draft for:
DOCUMENT TYPE: {document_type}
PARTIES: {parties}
EFFECTIVE DATE: {effective_date}
USER TERMS: {terms}

Requirements:
1. Use only facts supplied by the user. Do not invent names, addresses, money amounts,
   governing jurisdictions, statutes, deadlines, or other material facts.
2. Produce a coherent legal-document draft with a clear title and numbered sections.
3. Incorporate the supplied terms faithfully.
4. If a material fact is missing, use a visible placeholder such as [INSERT GOVERNING LAW]
   instead of silently inventing it.
5. Use plain, professional legal language.
6. Include signature blocks where appropriate.
7. Do not include Markdown fences, commentary about being an AI, or a legal disclaimer inside
   the document itself.
8. Do not claim the document is legally valid, enforceable, or jurisdiction-specific.
9. Finish with a short "User-Provided Terms" section that lists the supplied terms as bullets.

Return only the document text.
""".strip()

    def generate_document(
        self, document_type: str, parties: str, terms: str, effective_date: str
    ) -> str:
        prompt = self._prompt(document_type, parties, terms, effective_date)
        try:
            from google.genai import types
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0.25,
                    max_output_tokens=12000,
                ),
            )
            text = getattr(response, "text", None)
            if not text:
                raise GeminiGenerationError("Gemini returned an empty response.")
            return text.strip()
        except GeminiGenerationError:
            raise
        except Exception as exc:
            raise GeminiGenerationError(f"Gemini generation failed: {exc}") from exc
